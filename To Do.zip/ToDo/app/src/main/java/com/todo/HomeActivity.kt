 package com.todo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.todo.databinding.ActivityHomeBinding

 class HomeActivity : AppCompatActivity() {
    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.bottomNavigation.setOnItemSelectedListener {
            if (it.itemId != binding.bottomNavigation.selectedItemId) {
                when (it.itemId) {
                    R.id.tasks -> {
                        pushFragment(TasksFragment())
                    }
                    R.id.settings -> {
                        pushFragment(SettingsFragment())
                    }
                }
                return@setOnItemSelectedListener true
            }
            return@setOnItemSelectedListener false
        }


    }

     private fun pushFragment(fragment: Fragment) {
         supportFragmentManager.beginTransaction().replace(binding.content.fragmentContainer.id,fragment).commit()

     }
 }